/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tien;

/**
 *
 * @author Tien
 */
public class HabitGuide {
    
    public String getTutorial(){
        return " How to use Habit Builder: \n"
                + "- Enter a habit name and a brief description. \n"
                + "- Choose either yes or no you completed it today. \n" 
                + "- Press SAVE to store the habit. \n"
                + "- VIEW to see your saved habits. \n"
                + "- CLEAR to reset everything. \n"
                + "- Make sure to tick only one checkbox. \n";
    } 
}
