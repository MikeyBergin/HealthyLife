/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Michael;

/**
 *
 * @author mikey
 */
public class HealthTip {
    private String text;

    public HealthTip(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
